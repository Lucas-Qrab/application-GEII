package com.crab_corp.asso_geii;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.core.Tag;

import java.util.concurrent.TimeUnit;


public class MainActivity extends AppCompatActivity {

    private static final String TAG = "main";
    EditText user,mdp;
    TextView zone1,zone2;
    String profil="";
    String password="";
    private static String value="",value2="";


    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference check = database.getReference("check");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        user=(EditText)findViewById(R.id.editText);
        mdp=(EditText)findViewById(R.id.editText2);
        zone1=(TextView)findViewById(R.id.textView3);
        zone2=(TextView)findViewById(R.id.textView4);
        check.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String check= dataSnapshot.getValue(String.class);
                Log.d(TAG, "Value is: " + check);
            }
            @Override
            public void onCancelled(DatabaseError error) {
            }
        });

    }



    public void Connexion(View a) throws InterruptedException {
        zone1.setText("");
        if(user.getText().toString().length()==0||mdp.getText().toString().length()==0){
            zone1.setText("Tout les champs ne sont pas remplis" );
        }else {
            profil=user.getText().toString();
            password=mdp.getText().toString();
            FirebaseDatabase database = FirebaseDatabase.getInstance();
            DatabaseReference Profil = database.getReference("utilisateur").child(profil).child("Mot de passe");
            DatabaseReference Password =database.getReference("utilisateur").child(profil).child("Mot de passe");
            Profil.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    value = dataSnapshot.getValue(String.class);
                    Log.d(TAG, "Value is: " + value);
                }
                @Override
                public void onCancelled(DatabaseError error) {
                }
            });
            Thread.sleep(500);
            Password.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    value2 = dataSnapshot.getValue(String.class);
                    Log.d(TAG, "Value is: " + value2);
                }
                @Override
                public void onCancelled(DatabaseError error) {
                }
            });
            Thread.sleep(500);

            if (value.equalsIgnoreCase("null") ){
                Toast.makeText(getBaseContext(), "identifiant ou mot de passe incorrect", Toast.LENGTH_LONG).show();
                mdp.setText("");
            }
            else {
                if (value2.equals(password)){
                    Intent A;
                    A=new Intent(this,ecran_1.class);
                    startActivity(A);
                }
                else{
                    Toast.makeText(getBaseContext(), "identifiant ou mot de passe incorrect", Toast.LENGTH_LONG).show();
                    mdp.setText("");
                }
            }


        }
    }
}
