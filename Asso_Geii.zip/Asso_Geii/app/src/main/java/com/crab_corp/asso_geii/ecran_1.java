package com.crab_corp.asso_geii;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ecran_1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ecran_1);
    }

}
